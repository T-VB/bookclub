package com.dojo.authentication.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.dojo.authentication.models.Book;
import com.dojo.authentication.models.LoginUser;
import com.dojo.authentication.models.User;
import com.dojo.authentication.services.BookService;
import com.dojo.authentication.services.UserService;

@Controller
public class HomeController {

    @Autowired
    private UserService userServ;
    
    @Autowired
    private BookService bookServ;
    
    @GetMapping("/")
    public String index(Model model) {
    
        // ****BIND empty User and LoginUser objects to the JSP, to capture the form input
        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new LoginUser());
        //Bind above empty objects to jsp below by returning jsp page
        return "index.jsp";
    }
    
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser, 
            BindingResult result, Model model, HttpSession session) {
        
        User user = userServ.register(newUser, result);
        
        if(result.hasErrors()) {
            // Be sure to send in the empty LoginUser before 
            // re-rendering the page.
            model.addAttribute("newLogin", new LoginUser());
            return "index.jsp";
        }
        
      //otherwise, set this user in session and redirect to dashboard
        session.setAttribute("userId", user.getId());
    
        return "redirect:/dashboard";
    }
    
    //login user using session, store id in db using session :
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
            BindingResult result, Model model, HttpSession session) {
        
        User user = userServ.login(newLogin, result);
    
        if(result.hasErrors() || user==null) {
            model.addAttribute("newUser", new User());
            return "index.jsp";
        }
        
      //otherwise, set this user in session and redirect to dashboard
        session.setAttribute("userId", user.getId());
    
        return "redirect:/dashboard";
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
    	//if no user is found, redirect to logout
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/logout";
    	}
    	//get userId from session, cast the result to a Long
    	model.addAttribute("books", bookServ.allBooks());
    	model.addAttribute("user", userServ.findById((Long)session.getAttribute("userId")));
    		return "dashboard.jsp";
    }
    //add GetMapping route for users to add a book while in session
    @GetMapping("/addBook")
    public String addBook(@ModelAttribute("book") Book book, Model model, HttpSession session) {
    	User user = userServ.findById((Long)session.getAttribute("userId"));
    	model.addAttribute("user", user);
    	
    	return "addBook.jsp";
    }
    //add PostMapping route for the books
    @PostMapping("/books")
    public String createBook(@Valid @ModelAttribute("book") Book book, BindingResult result) {
    	if (result.hasErrors()) {
    		return "addBook.jsp";
    	}
    	
    	bookServ.create(book);
    	return "redirect:/dashboard";
    	
    }
    
    @GetMapping("/books/{id}/edit")
    public String editBook(Model model, @PathVariable("id") Long id, HttpSession session) {
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/";
    	}
    	
    	Book book = bookServ.findById(id);
    	model.addAttribute("book", book);
    	
    	return "editBook.jsp";
    }
    
    @GetMapping("books/{id}")
    public String showBook(Model model, @PathVariable("id") Long id, HttpSession session) {
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/";
    	}
    		
    	//System.out.println("The following book will be saved to the database:" + book.getTitle()); //This works if you add local variable (Book book) to showBook after PathVar and before data type
    	
    	Book book = bookServ.findById(id);
    	model.addAttribute("book", book);
    	model.addAttribute("user", userServ.findById((Long)session.getAttribute("userId")));
    	
    	return "showBook.jsp";
    }
	
    @PutMapping("/books/{id}")
    public String updateBook(@Valid @ModelAttribute("book") Book book, BindingResult result, Model model) {
    	
    	if (result.hasErrors()) {
    		return "editBook.jsp";
    	}
    	
    	System.out.println("Book to be saved to DB: " + book.getId());

        bookServ.update(book);
        
    	
    	return "redirect:/dashboard";
    }
    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
    	//set userId to null, redirect to index page
    	session.setAttribute("userId", null);
    	return "redirect:/";
    }
}
