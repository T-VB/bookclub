package com.dojo.authentication.services;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.dojo.authentication.models.LoginUser;
import com.dojo.authentication.models.User;
import com.dojo.authentication.repositories.UserRepository;

@Service
public class UserService {

		@Autowired
	    private UserRepository repo;

	@Autowired
    private UserRepository userRepo;
    
    // ***register method gets called from the CONTROLLER whenever a user submits a registration form***
    public User register(User newUser, BindingResult result) {
    	// TO-DO - Reject values or register if no errors:
        
        // Reject if email is taken (present in database)
        // Reject if password doesn't match confirmation
        
        // Return null if result has errors
    
        // Hash and set password, save user to database
    	Optional<User> optionalUser = userRepo.findByEmail(newUser.getEmail());
    	// Reject if email is taken (present in database)
        if(optionalUser.isPresent()) {
        	result.rejectValue("email", "Matches", "This email is already associated in our db");;
        }
        // Reject if password doesn't match confirmation
    	if(!newUser.getPassword().equals(newUser.getConfirm())) {
    		result.rejectValue("confirm", "Matches", "The Confirm Password must match Password!");
    	}
    	
    	// Return null if result has errors
    	if(result.hasErrors()) {
    		return null;
    	}
    
        // Hash and set password, save user to database
    	String hashed = BCrypt.hashpw(newUser.getPassword(), BCrypt.gensalt());
    	newUser.setPassword(hashed);
    	newUser = repo.save(newUser);
    	return newUser;
        }

    public User login(LoginUser newLogin, BindingResult result) {
    	// TO-DO - Reject values:
        
    	// Find user in the DB by email
        // Reject if NOT present
        
        // Reject if BCrypt password match fails
    
        // Return null if result has errors
        // Otherwise, return the user object
    	Optional<User> optionalUser = userRepo.findByEmail(newLogin.getEmail());
        
    	// Find user in the DB by email
        // Reject if NOT present
    	if(!optionalUser.isPresent()) {
    		result.rejectValue("email", "Matches", "User not found!");
    		return null;
    	}
    	
    	// User exists, retrieve user from DB
    	User user = optionalUser.get();
        
        // Reject if BCrypt password match fails
    	if(!BCrypt.checkpw(newLogin.getPassword(), user.getPassword())) {
    	    result.rejectValue("password", "Matches", "Invalid Password!");
    	}
    	
    	// Return null if result has errors
    	if(result.hasErrors()) {
    		return null;
    	}
    	
        // Otherwise, return the user object
        return user;
    }
    
    public User findByEmail(String email) {
    	Optional<User> result = repo.findByEmail(email);
    	if(result.isPresent()) {
    		return result.get();
    	}
    	
    	return null;
    }
    
    public User findById(Long id) {
    	Optional<User> result = repo.findById(id);
    	if(result.isPresent()) {
    		return result.get();
    	}
    	return null;
    }
	
}
