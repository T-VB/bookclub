package com.dojo.authentication.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dojo.authentication.models.Book;
import com.dojo.authentication.repositories.BookRepository;

@Service
public class BookService {

	@Autowired
    private BookRepository repo;
    
    // ***register method gets called from the CONTROLLER whenever a user submits a form***
    public Book findById (Long id) {
    	
    	Optional<Book> result = repo.findById(id);
    	if(result.isPresent()) {
    		return result.get(); //.get is built in crud repository extension
    	}
    	
    	return null;
    }
    
    public List<Book> allBooks() {
    	return repo.findAll(); //.findAll is built in crud repository extension
    }
    
    public Book create(Book book) {
    	return repo.save(book); //.save is built in crud repository extension
    }
    
    public Book update(Book book) {
    	return repo.save(book);
    }
    public void delete(Book book) {
    	repo.delete(book); //.delete is built in crud repository extension
    }
}
