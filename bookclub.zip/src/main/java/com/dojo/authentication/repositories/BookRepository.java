package com.dojo.authentication.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dojo.authentication.models.Book;

@Repository
public interface BookRepository extends CrudRepository<Book, Long> {
	
	//create method that finds ALL books from Class Book into a List
	List<Book> findAll();
	
}
